# -*- coding: utf-8 -*-
"""LP3.ipynb
"""

#libraries
  import pandas as pd
  import numpy as np
  from sklearn.metrics import accuracy_score, confusion_matrix
  from sklearn.model_selection import train_test_split
  from sklearn.feature_extraction.text import TfidfVectorizer
  from sklearn.linear_model import PassiveAggressiveClassifier
 


#to upload file from device
from google.colab import files
uploaded = files.upload()

#read data
data = pd.read_csv("/content/news.csv")

#shape of data
data.shape          
(6335, 4)

data.head()

 	Unnamed: 0 	title 	text 	label
0 	8476 	You Can Smell Hillary’s Fear 	Daniel Greenfield, a Shillman Journalism Fello... 	FAKE
1 	10294 	Watch The Exact Moment Paul Ryan Committed Pol... 	Google Pinterest Digg Linkedin Reddit Stumbleu... 	FAKE
2 	3608 	Kerry to go to Paris in gesture of sympathy 	U.S. Secretary of State John F. Kerry said Mon... 	        REAL
3 	10142 	Bernie supporters on Twitter erupt in anger ag... 	— Kaydee King (@KaydeeKing) November 9, 2016 T... 	FAKE
4 	875 	The Battle of New York: Why This Primary Matters 	It's primary day in New York and front-runners... 	REAL

data.tail()

Unnamed: 0 	title 	text 	label
6330 	4490 	State Department says it can't find emails fro... 	The State Department told the Republican Natio... 	REAL
6331 	8062 	The ‘P’ in PBS Should Stand for ‘Plutocratic’ ... 	The ‘P’ in PBS Should Stand for ‘Plutocratic’ ... 	FAKE
6332 	8622 	Anti-Trump Protesters Are Tools of the Oligarc... 	Anti-Trump Protesters Are Tools of the Oligar... 	FAKE
6333 	4021 	In Ethiopia, Obama seeks progress on peace, se... 	ADDIS ABABA, Ethiopia —President Obama convene... 	REAL
6334 	4330 	Jeb Bush Is Suddenly Attacking Trump. Here's W... 	Jeb Bush Is Suddenly Attacking Trump. Here's W... 	REAL


labels=data.label

#data is splitted into train and test
x_train,x_test,y_train,y_test=train_test_split(data['text'],labels,test_size=0.25, random_state=8)


#tfidvectorizer used to drop unnecessary data
vectorizer=TfidfVectorizer( stop_words='english',decode_error='strict',analyzer='word',ngram_range=(1, 2))

X_Train=vectorizer.fit_transform(x_train) 
X_Test=vectorizer.transform(x_test)

#train test size
print(X_Train.shape)
print(y_train.shape) 
print(X_Test.shape)
print(y_test.shape)

(4751, 1284019)
(4751,)
(1584, 1284019)
(1584,)



#passiveaggresiveclassifier 
nlm = PassiveAggressiveClassifier(max_iter=1000,random_state=0)
nlm.fit(X_Train,y_train)
PassiveAggressiveClassifier(random_state=0)
y_pred=nlm.predict(X_Test)

#accuracy
score = accuracy_score(y_test, y_pred)
print("accuracy:%0.3f" %(score*100))

accuracy:94.066

#scikit-plot install
pip install scikit-plot

#confusion matrix
import scikitplot as skplt

skplt.metrics.plot_confusion_matrix(y_test,y_pred,labels=['FAKE','REAL'])


